CREATE DATABASE IF NOT EXISTS hms_db;
USE hms_db;

-- ADMIN TABLE 
CREATE TABLE `admin` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `profile` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `admin` (`username`, `password`, `profile`) VALUES
('admin', '12345678', 'admin.jpg'),
('admin2', '012345678', 'OIP (7).jpg');

-- PATIENT TABLE
CREATE TABLE `patient` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `date_reg` varchar(100) NOT NULL,
  `profile` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `patient` 
(`username`, `firstname`, `surname`, `email`, `phone`, `gender`, `location`, `password`, `date_reg`, `profile`)
VALUES
('patient1', 'Demo', 'UserOne', 'user1@gmail.com', '01711111111', 'Male', 'Dhaka', '12345', '2025-01-01', 'patient1.jpg'),
('patient2', 'Demo', 'UserTwo', 'user2@gmail.com', '01822222222', 'Female', 'Chittagong', '12345', '2025-01-01', 'patient2.jpg');

-- APPOINTMENT TABLE
CREATE TABLE `appointment` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `appointment_date` varchar(100) NOT NULL,
  `symptoms` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `date_booked` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- REPORT TABLE
CREATE TABLE `report` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `message` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `date_send` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- DOCTORS TABLE 
CREATE TABLE `doctors` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `salary` varchar(100) NOT NULL DEFAULT '0',
  `date_reg` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `profile` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `doctors` (`firstname`, `surname`, `username`, `email`, `gender`, `phone`, `country`, `password`, `salary`, `date_reg`, `status`, `profile`) VALUES
('Dr. Kabir', 'Chy', 'drkabir', 'kabir@clinic.com', 'Male', '01712345678', 'Bangladesh', '12345678', '40000', '2025-01-20', 'Approved', 'dr_kabir.jpg'),
('Dr. Nasrin', 'Akter', 'drnasrin', 'nasrin@clinic.com', 'Female', '01898765432', 'India', '12345678', '0', '2025-01-21', 'Pending', 'default_doc.jpg');

-- INCOME TABLE 
CREATE TABLE `income` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `doctor` varchar(100) NOT NULL,
  `patient` varchar(100) NOT NULL,
  `date_dischage` varchar(100) NOT NULL,
  `amount_paid` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

