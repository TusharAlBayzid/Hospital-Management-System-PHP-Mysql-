<?php


$connect = mysqli_connect("localhost", "root", "", "hms_db", 3307);
#Tushar&Nusrat29  hms_db 

if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}

?>