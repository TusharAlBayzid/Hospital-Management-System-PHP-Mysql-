<!DOCTYPE html>

<head>
    <title></title>
</head>

<body>
    <div class="list-group  bg-info" style="height: 90vh;">
        <a href="index.php"
            class="list-group-item list-group-action-action bg-info text-center text-white">Dashboard</a>
        <a href="profile.php"
            class="list-group-item list-group-action-action bg-info text-center text-white">Profile</a>
        <a href="admin.php"
            class="list-group-item list-group-action-action bg-info text-center text-white">Administrators</a>
        <a href="doctor.php" class="list-group-item list-group-action-action bg-info text-center text-white">Doctors</a>
        <a href="patient.php"
            class="list-group-item list-group-action-action bg-info text-center text-white">Patient</a>
        <a href="job_request.php"
            class="list-group-item list-group-action-action bg-info text-center text-white">Job Request</a>
    </div>
</body>

</html>