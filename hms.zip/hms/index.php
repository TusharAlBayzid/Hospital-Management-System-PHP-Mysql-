<!DOCTYPE html>
<html>
<head>
    <title>HMS Home page</title>
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <style>
        /* Smooth Cross-fade Transition */
        .carousel-fade .carousel-item {
            opacity: 0;
            transition-duration: 1s; /* ছবির পরিবর্তন ১ সেকেন্ড সময় নিবে */
            transition-property: opacity;
        }
        .carousel-fade .carousel-item.active {
            opacity: 1;
        }

        .carousel-item img {
            height: 550px;
            object-fit: cover;
            filter: brightness(80%);
        }

        .section-title {
            border-left: 5px solid #17a2b8;
            padding-left: 15px;
            margin-bottom: 30px;
            font-weight: bold;
            color: #333;
        }

        .about-box {
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        }

        .contact-card {
            background-color: #17a2b8;
            color: white;
            padding: 25px;
            border-radius: 10px;
        }

        footer {
            background: #212529;
            color: #ccc;
            padding: 40px 0 20px;
            margin-top: 60px;
        }
    </style>
</head>
<body>
    <?php include("include/header.php"); ?>

    <div id="hmsSlider" class="carousel slide carousel-fade shadow" data-bs-ride="carousel" data-bs-interval="5000">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#hmsSlider" data-bs-slide-to="0" class="active"></button>
            <button type="button" data-bs-target="#hmsSlider" data-bs-slide-to="1"></button>
            <button type="button" data-bs-target="#hmsSlider" data-bs-slide-to="2"></button>
            <button type="button" data-bs-target="#hmsSlider" data-bs-slide-to="3"></button>
            <button type="button" data-bs-target="#hmsSlider" data-bs-slide-to="4"></button>
        </div>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="image/slide1.jpg" class="d-block w-100" alt="HMS 1">
                <div class="carousel-caption d-none d-md-block">
                    <h2 class="display-4 fw-bold">Best Medical Care</h2>
                    <p class="fs-5">Providing compassionate care with advanced technology.</p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="image/slide2.jpg" class="d-block w-100" alt="HMS 2">
                <div class="carousel-caption d-none d-md-block">
                    <h2 class="display-4 fw-bold">Qualified Specialist Doctors</h2>
                    <p class="fs-5">Expert consultants are available 24/7 for you.</p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="image/slide3.jpg" class="d-block w-100" alt="HMS 3">
                <div class="carousel-caption d-none d-md-block">
                    <h2 class="display-4 fw-bold">Emergency Support</h2>
                    <p class="fs-5">We are always ready to handle critical situations.</p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="image/slide4.jpg" class="d-block w-100" alt="HMS 4">
                <div class="carousel-caption d-none d-md-block">
                    <h2 class="display-4 fw-bold">Pharmacy & Lab Services</h2>
                    <p class="fs-5">Accurate results and authentic medicines for patients.</p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="image/slide5.jpg" class="d-block w-100" alt="HMS 5">
                <div class="carousel-caption d-none d-md-block">
                    <h2 class="display-4 fw-bold">Hygienic Environment</h2>
                    <p class="fs-5">Ensuring a clean and safe space for quick recovery.</p>
                </div>
            </div>
        </div>
    </div>

    <div class="container my-5 pt-4">
        <div class="row text-center g-4">
            <div class="col-md-4">
                <div class="card h-100 shadow border-0 p-3">
                    <img src="image/more info.webp" class="card-img-top rounded mx-auto" style="width: 80%; height: 200px; object-fit: contain;">
                    <div class="card-body">
                        <h5 class="card-title fw-bold">Need Information?</h5>
                        <p class="text-muted small">Learn about our hospital history, facilities and world-class management.</p>
                        <a href="include/moreinfo.php" class="btn btn-outline-info w-100 py-2 mt-2">More Information</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card h-100 shadow border-0 p-3">
                    <img src="image/patient.jpg" class="card-img-top rounded mx-auto" style="width: 80%; height: 200px; object-fit: contain;">
                    <div class="card-body">
                        <h5 class="card-title fw-bold">Are You a Patient?</h5>
                        <p class="text-muted small">Join us to book appointments easily and manage your health records.</p>
                        <a href="include/account.php" class="btn btn-info text-white w-100 py-2 mt-2">Create Account!!!</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card h-100 shadow border-0 p-3">
                    <img src="image/doctor.jpg" class="card-img-top rounded mx-auto" style="width: 80%; height: 200px; object-fit: contain;">
                    <div class="card-body">
                        <h5 class="card-title fw-bold">Doctor Careers</h5>
                        <p class="text-muted small">Apply to become a part of our professional medical team.</p>
                        <a href="include/apply.php" class="btn btn-outline-info w-100 py-2 mt-2">Apply Now!!!</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container my-5">
        <div class="row">
            <div class="col-md-8 mb-4">
                <h3 class="section-title text-uppercase">About Us</h3>
                <div class="about-box">
                    <p class="lead fw-bold text-info">Modernizing Healthcare Excellence</p>
                    <p class="text-secondary" style="line-height: 1.8; text-align: justify;">
                        The Hospital Management System (HMS) is a digital solution for the modern healthcare era. Our goal is to streamline the interaction between patients and doctors by automating record-keeping and appointment scheduling. We believe in providing quality treatment through qualified doctors and 24/7 health services.
                    </p>
                    <div class="row mt-4">
                        <div class="col-6 col-md-3 text-center">
                            <i class="fa-solid fa-user-doctor fa-2x text-info mb-2"></i>
                            <h6 class="fw-bold">Expert Doctors</h6>
                        </div>
                        <div class="col-6 col-md-3 text-center">
                            <i class="fa-solid fa-truck-medical fa-2x text-info mb-2"></i>
                            <h6 class="fw-bold">Emergency</h6>
                        </div>
                        <div class="col-6 col-md-3 text-center">
                            <i class="fa-solid fa-microscope fa-2x text-info mb-2"></i>
                            <h6 class="fw-bold">Modern Lab</h6>
                        </div>
                        <div class="col-6 col-md-3 text-center">
                            <i class="fa-solid fa-clock fa-2x text-info mb-2"></i>
                            <h6 class="fw-bold">24/7 Service</h6>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <h3 class="section-title text-uppercase">Our Address</h3>
                <div class="contact-card shadow-sm h-100">
                    <h5 class="mb-4 fw-bold"><i class="fa-solid fa-building-user me-2"></i> Contact Info</h5>
                    <div class="mb-3 d-flex align-items-start">
                        <i class="fa-solid fa-location-dot mt-1 me-3"></i>
                        <span>Medical Road, Kajalshah, Sylhet - 3100, Bangladesh.</span>
                    </div>
                    <div class="mb-3 d-flex align-items-center">
                        <i class="fa-solid fa-phone me-3"></i>
                        <span>+880 1234-567890</span>
                    </div>
                    <div class="mb-3 d-flex align-items-center">
                        <i class="fa-solid fa-envelope me-3"></i>
                        <span>contact@hms.com</span>
                    </div>
                    <div class="mt-4 pt-3 border-top border-light">
                        <p class="mb-0 fw-bold">Service Hours:</p>
                        <small>Saturday - Thursday (24/7)</small>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer>
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                    <h4 class="text-white fw-bold mb-2">HMS Portal</h4>
                    <p class="mb-0">A complete healthcare management solution.</p>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <div class="mb-3">
                        <a href="#" class="text-white mx-2"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="text-white mx-2"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-white mx-2"><i class="fab fa-linkedin-in"></i></a>
                        <a href="#" class="text-white mx-2"><i class="fab fa-instagram"></i></a>
                    </div>
                    <small>&copy; 2026 HMS Management System. All Rights Reserved.</small>
                </div>
            </div>
        </div>
    </footer>

</body>
</html>
